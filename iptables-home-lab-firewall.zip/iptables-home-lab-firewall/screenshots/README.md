# Screenshots

Terminal evidence for the results in the main README. Suggested file names:

| File | What it shows |
|---|---|
| `01-final-ruleset.png` | `sudo iptables -L -v -n` with the final rules and the corrected `Blocked-21: ` prefix |
| `02-ping-and-nc-tests.png` | Ping statistics (401 sent, 401 received, 0% loss) and the `nc` timeouts from the client |
| `03-blocked-443-log.png` | `sudo dmesg \| grep -i blocked` showing `Blocked-443: ` entries with `SRC=172.90.23.4` |
| `04-blocked-21-log.png` | Same command after the prefix fix, showing a `Blocked-21: ` entry (not captured yet) |

To capture the last one, run `nc -zv 172.90.23.3 21` on the client, then `sudo dmesg | grep "Blocked-21"` on the firewall.
