#!/usr/bin/env bash
# Removes every rule and returns all chains to ACCEPT.
# Run on the firewall VM (Kali): sudo ./reset.sh
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
    echo "Run as root: sudo $0" >&2
    exit 1
fi

iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT
iptables -F
iptables -X

echo "All rules removed; every chain is back to ACCEPT:"
iptables -L -v -n
