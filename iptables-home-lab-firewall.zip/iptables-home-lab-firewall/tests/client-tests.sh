#!/usr/bin/env bash
# Run on the client VM (Ubuntu) against the firewall's IP address:
#   ./tests/client-tests.sh 172.90.23.3
set -u

FW_IP="${1:-}"
if [[ -z "$FW_IP" ]]; then
    echo "Usage: $0 FIREWALL_IP   (for example: $0 172.90.23.3)" >&2
    exit 1
fi

pass=0
fail=0

echo "Allowed traffic"
if ping -c 3 -W 2 "$FW_IP" > /dev/null 2>&1; then
    echo "  PASS  ping reached $FW_IP"
    pass=$((pass + 1))
else
    echo "  FAIL  no ping reply from $FW_IP"
    fail=$((fail + 1))
fi

echo "Blocked traffic (each check waits up to 5 seconds)"
for port in 80 443 21; do
    if nc -z -w 5 "$FW_IP" "$port" > /dev/null 2>&1; then
        echo "  FAIL  port $port is reachable but should be blocked"
        fail=$((fail + 1))
    else
        echo "  PASS  port $port blocked (no connection)"
        pass=$((pass + 1))
    fi
done

echo
echo "Result: $pass passed, $fail failed"
[[ $fail -eq 0 ]]
