#!/usr/bin/env bash
# Rebuilds the home-lab firewall ruleset from scratch.
# Run on the firewall VM (Kali): sudo ./firewall.sh
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
    echo "Run as root: sudo $0" >&2
    exit 1
fi

# Open every policy first so flushing the old rules can't lock you out
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT
iptables -F

# Allow rules go in before the default DROP policy
iptables -A INPUT -i lo -j ACCEPT
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
iptables -A INPUT -p tcp --dport 22 -j ACCEPT
iptables -A INPUT -p icmp --icmp-type echo-request -j ACCEPT

# Explicitly block and log HTTPS and FTP (LOG must come before DROP)
iptables -A INPUT -p tcp --dport 443 -j LOG --log-prefix "Blocked-443: "
iptables -A INPUT -p tcp --dport 443 -j DROP
iptables -A INPUT -p tcp --dport 21 -j LOG --log-prefix "Blocked-21: "
iptables -A INPUT -p tcp --dport 21 -j DROP

# Default-deny everything else coming in; outbound stays open for updates and DNS
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT

echo "Firewall rules applied:"
iptables -L -v -n --line-numbers
