# iptables Home Lab Firewall

A beginner firewall project: a default-deny `iptables` ruleset on Kali Linux, tested from a separate Ubuntu client VM, with logging for blocked connection attempts.

## What this project shows

- Building a **default-deny** firewall: INPUT and FORWARD default to DROP, with explicit allows for the traffic the machine needs
- Why **rule order** matters: the first matching rule wins, and `LOG` has to come before `DROP`
- **Testing from the other side** of the connection instead of trusting the rules on paper
- Reading **kernel firewall logs** to see which machine tried to reach which blocked port

## Lab setup

| Machine | Role | IP address |
|---|---|---|
| Kali Linux VM | Firewall (the machine being protected) | 172.90.23.3 |
| Ubuntu VM | Client used for testing | 172.90.23.4 |

Both VMs run in VirtualBox on the same virtual network.

## The ruleset

`firewall.sh` rebuilds this from scratch:

| # | Rule | Purpose |
|---|---|---|
| 1 | `-A INPUT -i lo -j ACCEPT` | Allow loopback traffic (local services talk to themselves) |
| 2 | `-A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT` | Allow replies to connections this machine started |
| 3 | `-A INPUT -p tcp --dport 22 -j ACCEPT` | Allow SSH |
| 4 | `-A INPUT -p icmp --icmp-type echo-request -j ACCEPT` | Allow ping |
| 5 | `-A INPUT -p tcp --dport 443 -j LOG --log-prefix "Blocked-443: "` | Log HTTPS attempts |
| 6 | `-A INPUT -p tcp --dport 443 -j DROP` | Block HTTPS |
| 7 | `-A INPUT -p tcp --dport 21 -j LOG --log-prefix "Blocked-21: "` | Log FTP attempts |
| 8 | `-A INPUT -p tcp --dport 21 -j DROP` | Block FTP |

Default policies: `INPUT DROP`, `FORWARD DROP`, `OUTPUT ACCEPT`.

The screenshots show the same rules in a slightly different order, because I added the 443 and 21 rules before rebuilding the allow rules. The script applies them in the order above. The behavior is the same, since none of the allowed traffic matches ports 443 or 21.

## How to run it

Make the scripts executable once:

```bash
chmod +x firewall.sh reset.sh tests/client-tests.sh
```

On the **Kali firewall VM**:

```bash
sudo ./firewall.sh
```

On the **Ubuntu client VM**:

```bash
./tests/client-tests.sh 172.90.23.3
```

To undo everything and return to an open firewall:

```bash
sudo ./reset.sh
```

## Results

**Allowed traffic.** Ping from the client to the firewall:

```
401 packets transmitted, 401 received, 0% packet loss
```

**Blocked traffic.**

- `nc -zv 172.90.23.3 80` failed with `Connection timed out`. Port 80 has no rule of its own, so the default DROP policy caught it.
- Ports 443 and 21 hit their explicit rules. The packet counters on those rules showed 22 packets (1320 bytes) matched on 443 and 11 packets (660 bytes) on 21, and the kernel log recorded each attempt.

**Log evidence.** On this Kali install `/var/log/kern.log` does not exist, so I read the kernel ring buffer instead:

```bash
sudo dmesg | grep -i blocked
```

A logged attempt on port 443 (MAC address shortened):

```
Blocked-443: IN=eth0 OUT= MAC=... SRC=172.90.23.4 DST=172.90.23.3 LEN=60 ... PROTO=TCP SPT=42048 DPT=443 ... SYN
```

`SRC` is the Ubuntu client and `DPT=443` is the blocked port. The same source port repeats with growing gaps between entries, which is the client retransmitting its SYN packet because it never gets an answer.

## Why the blocked connections hang instead of failing fast

`DROP` silently discards the packet, so the client keeps retrying until it gives up with a timeout. `REJECT` would send back an immediate "connection refused". DROP is slower for the client, but it tells a scanner nothing about whether a port is closed, filtered, or the host is even up.

## What I learned

- **Rule order is everything.** `LOG` is non-terminating, so it must sit before the matching `DROP`. Once a packet is dropped, no later rule sees it.
- **Allow rules go in before the default DROP policy.** Setting DROP first would cut off SSH and loopback traffic. For the same reason `firewall.sh` sets every policy to ACCEPT before flushing the old rules.
- **iptables rules live in memory.** After a break from the lab my earlier rules were gone, so I rebuilt them, which is why this repo has a script.
- **A wrong log prefix is easy to miss.** My first port 21 LOG rule reused the `Blocked-443: ` prefix, so port 21 attempts showed up under the wrong label. I caught it by reading the log, deleted the rule with `iptables -D INPUT <line-number>`, and re-added it with the right prefix. Line numbers shift after every delete, so list the chain again between deletes.

## Next steps

- Re-run the 21 test and capture a log line under the corrected `Blocked-21: ` prefix
- Rewrite the ruleset in `nftables` and compare the two
- Limit SSH to the client's IP only, using `-s 172.90.23.4`
- Rate-limit ICMP to blunt ping floods
- Run `nmap` from another machine before and after the rules go in
- Add `ip6tables` rules, since this ruleset only covers IPv4
- Make the rules persist across reboots with `iptables-persistent`

## Repository layout

```
.
├── README.md
├── firewall.sh            # builds the ruleset
├── reset.sh               # removes all rules
├── tests/
│   └── client-tests.sh    # run from the client VM
└── screenshots/           # terminal evidence
```
